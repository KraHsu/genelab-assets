# Unitree Go2-W

Wheeled variant of the Unitree Go2 quadruped: the four feet are replaced by
driven wheels, giving **16 actuated DoF** — 12 leg joints (`hip` / `thigh` /
`calf` × 4) plus 4 `wheel` joints (one per leg).

- `go2w.xml` — the robot model (entry MJCF).
- `scene.xml` — `go2w.xml` on a checkered ground plane with a small obstacle course.
- `assets/` — visual (`.obj`) and collision (`.stl`) meshes referenced by `go2w.xml`.

## Source & license

Mirrored from [`unitreerobotics/unitree_mujoco`](https://github.com/unitreerobotics/unitree_mujoco)
(`unitree_robots/go2w`), released by Unitree Robotics under the **BSD-3-Clause**
license (see `LICENSE`). Unused upstream assets (terrain meshes, spare wheel) were
pruned; the mesh set here is exactly what `go2w.xml` declares.

The model has no `keyframe` home pose; downstream configs define the standing pose.
